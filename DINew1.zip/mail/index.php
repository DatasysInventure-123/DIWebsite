<?php

    header("location:https://mail.zoho.com/portal/datasysinventure"); 
?>